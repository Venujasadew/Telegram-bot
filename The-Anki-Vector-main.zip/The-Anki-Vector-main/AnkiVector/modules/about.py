__help__ = """
** Anki Vector - A Powerful Telegram Group Manager 🎶 **

Powerful Abilities

• Group Voice Chat Music Play ❤️

• File To Link and URL Upload 📂

• Youtube Downloader 🎵

Developer [Damantha🇱🇰](https://t.me/Damantha_Jasinghe)
"""
__mod_name__ = "About"
